<html>
	<head>
		<title>DLI</title>
	</head>
	<body>
		<div>
			<h1>DLI</h1>
		</div>
		<div>
			<a href="translator.php">Translator</a>
		</div>
		<div>
			<a href="ettiquite.php">Ettiquite</a>
		</div>
		<div>
			<a href="taste-of-home.php">Taste of Home</a>
		</div>
		<div>
			<a href="meetups.php">Meetups</a>
		</div>
		<div>
			<a href="contact-us.php">Contact Us</a>
		</div>

	</body>
</html>
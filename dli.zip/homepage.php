<!--TinyUrl is http://tinyurl.com/j2uu22o-->

<html>
	<head>
		<title>DLI</title>
		<link rel="stylesheet" type="text/css" href="css/homepage.css">
	</head>
	<body>
		<!--div id="wrapper"-->
			<header id="header">
				<h1 class="logo"><a href="homepage.php"><img src="http://i.imgur.com/47112La.png?1"></a></h1>
				<!--span class="header-description">Bringing Communities Together<span-->
			</header>
			<div id="container">
				<a href="translator.php"><div class="select fade">
					Translator
				</div>
				<a href="ettiquite.php"><div class="select fade">
					Ettiquite
				</div></a>
				<a href="taste-of-home.php"><div class="select">
					Taste of Home
				</div></a>
				<a href="meetups.php"><div class="select">
					Meetups
				</div></a>
				<a href="contact-us.php"><div class="select">
					Contact Us
				</div></a>
			</div>
		<!--/div-->
	</body>
</html>
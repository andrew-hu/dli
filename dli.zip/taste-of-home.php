<html>
	<head>
		<title>DLI</title>
	</head>
	<body>
		<div>
			<h1>DLI Taste of Home</h1>
		</div>
		<div>
			Info here
		</div>


	</body>
</html>
<html>
	<head>
		<title>DLI</title>
	</head>
	<body>
		<div>
			<h1>DLI Ettiquite Guide</h1>
		</div>
		<div>
			Info here
		</div>


	</body>
</html>
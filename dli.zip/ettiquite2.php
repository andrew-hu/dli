<html>
	<head>
		<title>DLI</title>
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	</head>
	<body>
		<div>
			<h1>DLI Ettiquite Guide between USA and Syria</h1>
			<h1> دليل الادب بين اوربا وسوريا </h1>
		</div>
		<div>
		    <img
           width="586" height="389"><br></br>
          Norway: Time is critical in Norway; make sure you're sharp on time.
          <br></br>
          Arabic Translation:
         <br></br>
         <div>
		    <img
           width="586" height="389"><br></br>
          Germany: No being late; considered thoughtless and rude.Being late in German culture is seen as extremely thoughtless and rude.
          <br></br>You should also be prepared to dress nicely most of the time, as dressing casually is looked down upon. There are also no women in higher positions; those are all controlled by the men.
          <br></br>
          Arabic Translation:التاخير غير مقبول. الحضورالمتاخر يعتبر سلوك غير مهذب في الثقافة الألمانية .يجب أيضا أن تكون مستعد بلباس لطيف في معظم الوقت، ولبس الملابس العادية يعتبرشي مستهان به. كما أنه لا توجد نساء في المناصب العليا. المناصب العالية ماخوذة من قبل الرجال.
         <br></br>
		</div>

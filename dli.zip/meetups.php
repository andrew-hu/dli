<html>
	<head>
		<title>DLI</title>
	</head>
	<body>
		<div>
			<h1>DLI Meetups</h1>
		</div>
		<div>
			Name
			Event Name
			Date/Time
			Location
			Description
		</div>


	</body>
</html>

<html>
	<head>
		<title>DLI</title>
		<link rel="stylesheet" type="text/css" href="css/homepage.css">
	</head>
	<body>
		<header id="header">
				<h1 class="logo"><a href="homepage.php"><img src="http://i.imgur.com/47112La.png?1"></a></h1>
				<!--span class="header-description">Bringing Communities Together<span-->
		</header>
		<div>
			<h1>Our Mission</h1>
			We are a team of 4 students currently enrolled in engineering. We were assigned to make a project that could help people in any sort of way.
			 We chose to do this Direct Language Interaction since the Syrian refugee crisis is something that not many people want to address. We find
			 it important to help our fellow human beings out by making them as comfortable as possible in an unfamiliar environment.Currently, our program
			  is designed for the refugees in the Americas, but we hope to eventually expand our project to help them worldwide.
		<br></br>
		</div>
		<div>
		</div>
		<div>
			<h1>Contact Us</h1>
		</div>
		<div>
			Andrew Hu - primoriscruor1@gmail.com
		</div>
		<div>
		    Rana Shamoun - rana200035@yahoo.com
		</div>


	</body>
</html>
